#include "Item.h"
#include "App.h"
#include "Textures.h"
#include "Audio.h"
#include "Input.h"
#include "Render.h"
#include "Scene.h"
#include "Log.h"
#include "Point.h"

Item ::Item() : Entity(EntityType::PLAYER)
{
	name.Create("Item");
}

Item::~Item() {

}

bool Item::Awake() {

	//L02: TODO 1: Initialize Player parameters
	position.x = 0;
	position.y = 0;

	texturePath = "Assets/Textures/goldCoin.png";



	return true;
}

bool Item::Start() {
	texture = app->tex->Load(texturePath);
	return true;
}

bool Item::Update()
{
	app->render->DrawTexture(texture, position.x, position.y);
	return true;
}

bool Item::CleanUp()
{

	return true;
}